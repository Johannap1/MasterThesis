//
// C++ Listing Test
//

#include <stdio.h>

for(int i=0;i<10;i++)
{
    cout << "Ok\n";
}
