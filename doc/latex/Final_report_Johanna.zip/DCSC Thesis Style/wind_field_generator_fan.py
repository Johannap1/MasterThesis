fans = {
    'fan1': {
        "x_pos": -10,
        "y_pos": 0,
        "size": 2,
        "x_dir": 0,
        "y_dir": 1,
        "strength": 5,
        "spread": 0.25,
        "decrease": 0.25,
    }
    'fan2': {
            "x_pos": -10,
            "y_pos": 0,
            "size": 2,
            "x_dir": 0,
            "y_dir": 1,
            "strength": 3,
            "spread": 0.15,
            "decrease": 0.15,
        }
}