from itertools import permutations
from math import dist
import numpy as np
from python_tsp.exact import solve_tsp_dynamic_programming
from hovergames_simplesim_control import helpers

def create_distance_matrix(X_path):
    distance_matrix = np.zeros((X_path.shape[0],X_path.shape[0]))
    for i in range(X_path.shape[0]):
        for j in range(X_path.shape[0]):
            distance = helpers.compute_coordinate_distance(X_path[i], X_path[j])
            distance_matrix[i,j] = distance
    return distance_matrix

def compute_permutation(X_path):
    distance_matrix = create_distance_matrix(X_path)
    permutation, distance = solve_tsp_dynamic_programming(distance_matrix)
    return permutation

def solve_tsp(X_path, X_last):
    X = np.vstack((X_last, X_path)) #Add the current last point to TSP
    permutation = compute_permutation(X)
    X_tsp = X[permutation,:]
    X_tsp = X_tsp[1:,:] #Exclude the first point from list again
    return X_tsp
